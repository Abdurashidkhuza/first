var openBtn = document.querySelector(".burger")
var closeBtn = document.querySelector(".close")

openBtn.addEventListener('click', () => {
    document.body.classList.add("ochilish")
})

closeBtn.addEventListener('click', () => {
    document.body.classList.remove("ochilish")
})